# Court's TV — Android V1

Aplicativo Android nativo em Kotlin, com interface escura, tela inicial, categorias demonstrativas e reprodução de vídeo via AndroidX Media3/ExoPlayer.

## Importante
- Esta V1 é um protótipo funcional com um vídeo público de demonstração. Não inclui backend, cadastro/login, catálogo próprio, uploads, assinaturas, painel administrativo ou direitos de distribuição de filmes.
- Para streaming real, substitua o vídeo de exemplo por URLs HTTPS de conteúdo que você tem autorização para distribuir e implemente uma API/backend.
- A compilação não foi executada neste ambiente: não há Android SDK nem Gradle instalado. Portanto, este pacote é o projeto-fonte, não um APK já compilado.

## Compilar somente pelo celular Android
1. Instale o **AndroidIDE** de uma fonte oficial/confiável compatível com seu dispositivo, ou use outro IDE Android no próprio celular que suporte projetos Gradle Android.
2. Extraia `CourtsTV-Android-Project.zip` para uma pasta local.
3. Abra a pasta `CourtsTV` no IDE e aguarde a sincronização Gradle. É necessária conexão à internet para baixar Gradle/dependências e SDKs compatíveis.
4. Se o IDE solicitar, instale/seleciona Android SDK 35 e JDK 17.
5. Execute a tarefa `:app:assembleDebug`.
6. O APK de depuração deverá ser gerado em `app/build/outputs/apk/debug/app-debug.apk`. Instale-o no próprio celular e autorize a instalação dessa fonte, se solicitado.

## Requisitos do projeto
- Android Studio/AndroidIDE compatível com Gradle Android Plugin 8.7.3
- JDK 17
- Android SDK 35
- Internet para dependências e vídeo demonstrativo

## Identificação
- Application ID: `com.courtstv.app`
- Versão: `1.0` (versionCode 1)

# Compilar o Court's TV usando somente o celular

O projeto inclui um workflow do GitHub Actions que compila o APK em um servidor na nuvem, sem precisar instalar Android Studio ou Android SDK no celular.

1. Entre em https://github.com pelo navegador do celular e crie uma conta, se necessário.
2. Crie um repositório novo chamado `CourtsTV`.
3. Envie os arquivos e pastas que estão dentro da pasta `CourtsTV` deste ZIP (incluindo a pasta oculta `.github`). Não envie a pasta externa que contém tudo.
4. Abra a aba **Actions** do repositório e habilite workflows, se o GitHub solicitar.
5. Selecione **Build Court's TV APK** e toque em **Run workflow**. Também pode iniciar automaticamente ao enviar os arquivos para a branch `main`.
6. Quando a execução terminar com sucesso, abra a execução e baixe o artifact **CourtsTV-debug-apk**.
7. Extraia o ZIP do artifact e toque em `app-debug.apk` para instalar. Talvez seja necessário autorizar o navegador/gerenciador de arquivos a instalar apps desconhecidos.

O APK produzido é uma versão de depuração (debug), não uma versão assinada para publicação na Play Store. A compilação pode falhar se houver incompatibilidade ou erro no projeto; nesse caso, consulte os logs da execução.

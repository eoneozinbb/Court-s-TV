package com.courtstv.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        val title = TextView(this).apply { text = intent.getStringExtra("title") ?: "Reproduzindo"; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL; setPadding(20, 20, 20, 20) }
        val view = PlayerView(this).apply { useController = true }
        root.addView(title)
        root.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        player = ExoPlayer.Builder(this).build().also { exo -> view.player = exo; exo.setMediaItem(MediaItem.fromUri(intent.getStringExtra("url") ?: MainActivity.SAMPLE_VIDEO)); exo.prepare(); exo.playWhenReady = true }
    }
    override fun onStop() { super.onStop(); player?.release(); player = null }
}

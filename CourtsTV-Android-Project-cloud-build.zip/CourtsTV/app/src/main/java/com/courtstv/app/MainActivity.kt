package com.courtstv.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 16, 20)
    private val panel = Color.rgb(29, 29, 36)
    private val muted = Color.rgb(176, 176, 188)
    private val red = Color.rgb(229, 9, 20)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), dp(24)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "▶"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = rounded(red, 14); layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        }
        val brand = TextView(this).apply { text = "COURT'S TV"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); setPadding(dp(12), 0, 0, 0) }
        header.addView(logo); header.addView(brand); content.addView(header)
        content.addView(label("Seu entretenimento, do seu jeito.", 14f, muted, false).apply { setPadding(0, dp(8), 0, dp(22)) })
        content.addView(label("DESTAQUE", 12f, red, true))
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(20), dp(18), dp(18)); background = rounded(Color.rgb(48, 27, 35), 20) }
        hero.minimumHeight = dp(190)
        hero.addView(label("COURT'S ORIGINAL", 12f, Color.LTGRAY, true))
        hero.addView(label("Histórias que\nprendem você.", 28f, Color.WHITE, true).apply { setPadding(0, dp(12), 0, dp(10)) })
        hero.addView(label("Filmes • Séries • Vídeos", 14f, muted, false))
        val play = Button(this).apply { text = "▶  Assistir agora"; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(red); setOnClickListener { openPlayer("Trailer de demonstração", SAMPLE_VIDEO) } }
        hero.addView(play, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)).apply { topMargin = dp(12) })
        content.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        content.addView(sectionTitle("Continuar assistindo"))
        content.addView(videoCard("Trailer de demonstração", "Vídeo de exemplo • toque para reproduzir", SAMPLE_VIDEO))
        content.addView(sectionTitle("Explore por categoria"))
        val cats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Filmes", "Séries", "Música").forEach { name ->
            val chip = TextView(this).apply { text = name; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = rounded(panel, 24); setPadding(dp(18), dp(12), dp(18), dp(12)) }
            cats.addView(chip, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(7) })
        }
        content.addView(cats)
        content.addView(TextView(this).apply { text = "V1 • Catálogo de demonstração"; textSize = 12f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, dp(28), 0, dp(8)) })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(Color.rgb(21,21,26)) }
        listOf("⌂  Início", "⌕  Buscar", "♡  Minha lista").forEach { t -> nav.addView(TextView(this).apply { text=t; textSize=12f; setTextColor(if(t.contains("Início")) Color.WHITE else muted); gravity=Gravity.CENTER; setPadding(dp(8), dp(6), dp(8), dp(6)) }, LinearLayout.LayoutParams(0, -2, 1f)) }
        root.addView(nav)
        setContentView(root)
    }

    private fun sectionTitle(s: String) = label(s, 19f, Color.WHITE, true).apply { setPadding(0, dp(24), 0, dp(12)) }
    private fun videoCard(title: String, subtitle: String, url: String): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = rounded(panel, 16); isClickable = true; isFocusable = true; setOnClickListener { openPlayer(title, url) } }
        card.addView(label("▶", 24f, red, true))
        card.addView(label(title, 16f, Color.WHITE, true).apply { setPadding(0, dp(8), 0, dp(4)) })
        card.addView(label(subtitle, 13f, muted, false))
        return card
    }
    private fun openPlayer(title: String, url: String) { startActivity(Intent(this, PlayerActivity::class.java).putExtra("title", title).putExtra("url", url)) }
    private fun label(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply { text=s; textSize=size; setTextColor(color); if (bold) typeface=Typeface.DEFAULT_BOLD }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    companion object { const val SAMPLE_VIDEO = "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" }
}
